# config.py

DB_CONFIG = {
    "dbname": "datawarehouse_test",
    "user": "postgres",
    "password": "root",
    "host": "localhost",
    "port": "5432"
}

TICKERS =  ['AI.PA','AIR.PA','ALO.PA'
               ] 
SAVE_DIRECTORY = "./financial_data_lake"

SAVE_EXCEL = "./intraday_directory"

EMAIL_CONFIG = {
    "sender_email": "data_dev_supdevinci@outlook.fr",
    "receiver_email": "razafimahatratra.andriamandimbisoambelomasina@supdevinci-edu.fr",
    "smtp_server": "smtp.office365.com",
    "smtp_port": 587,
    "smtp_user": "data_dev_supdevinci@outlook.fr",
    "smtp_password": "Acer_vert_noix33%"
}

